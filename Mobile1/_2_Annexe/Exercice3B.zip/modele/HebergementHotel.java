package

public class HebergementHotel extends Produit{
    public HebergementHotel( int qteAchetee) {
        super("1 semaine d'hôtel", qteAchetee, 989.99);
    }
}
