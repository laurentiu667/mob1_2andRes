package 

public class BilletAvion extends Produit{

    public BilletAvion( int qteAchetee) {
        super("Billet d'avion", qteAchetee, 599.99);
    }
}
