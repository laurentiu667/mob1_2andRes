package 
public class Produit {
    private String nom;
    private int qte;
    private double prixUnitaire;

    public Produit(String nom, int qte, double prixUnitaire) {
        this.nom = nom;
        this.qte = qte;
        this.prixUnitaire = prixUnitaire;
    }

    public String getNom() {
        return nom;
    }

    public int getQte() {
        return qte;
    }

    public double getPrixUnitaire() {
        return prixUnitaire;
    }
}
