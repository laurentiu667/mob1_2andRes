package com.example.atelier5;

public interface ObservateurChangement {

    public void changement (int valeur);
}
