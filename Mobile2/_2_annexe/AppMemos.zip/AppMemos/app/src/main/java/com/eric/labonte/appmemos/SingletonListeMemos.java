package com.eric.labonte.appmemos;

import android.content.Context;
import java.util.ArrayList;

public class SingletonListeMemos {
    public static SingletonListeMemos instance;
    private ArrayList<Memo> liste;

    private  SingletonListeMemos()
    {
        liste = new ArrayList();

    }

    public static SingletonListeMemos getInstance()
    {
        if ( instance == null)
            instance = new SingletonListeMemos();
        return instance;
    }

    public void ajouterMemo ( Memo memo )
    {
        liste.add(memo);
    }

    public ArrayList<Memo> getListe()
    {
        return liste;
    }

    public void setListe(ArrayList<Memo> liste) {
        this.liste = liste;
    }








}
