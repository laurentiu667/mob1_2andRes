package com.eric.labonte.appmemos

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity () : AppCompatActivity() {
    lateinit var boutonAjouter: Button
    lateinit var boutonAfficher: Button
    lateinit var boutonQuitter: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v: View, insets: WindowInsetsCompat ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        boutonAjouter = findViewById(R.id.bAjouter)
        boutonAfficher = findViewById(R.id.bAfficher)
        boutonQuitter = findViewById(R.id.bQuitter)

        val ec = Ecouteur()
        boutonAjouter.setOnClickListener{v-> val i = Intent(this@MainActivity, AjouterActivity::class.java)
        startActivity(i)}
        boutonAfficher.setOnClickListener(ec)
        boutonQuitter.setOnClickListener(ec)

    }



    inner class Ecouteur : View.OnClickListener {
        override fun onClick(v: View) {
            if (v === boutonAjouter) {
                val i = Intent(this@MainActivity, AjouterActivity::class.java)
                startActivity(i)
            } else if (v === boutonAfficher) {
                val i = Intent(this@MainActivity, ListeActivity::class.java)
                startActivity(i)
            } else  // boutonQuitter
            {
                System.exit(0)
            }
        }
    }
}