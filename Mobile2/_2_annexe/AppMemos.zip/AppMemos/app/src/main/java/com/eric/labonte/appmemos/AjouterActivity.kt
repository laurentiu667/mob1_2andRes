package com.eric.labonte.appmemos

import android.app.DatePickerDialog
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import android.widget.DatePicker
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.BufferedWriter
import java.io.FileOutputStream
import java.io.ObjectOutputStream
import java.io.OutputStreamWriter
import java.time.LocalDate

class AjouterActivity : AppCompatActivity() {
    lateinit var champMemo: EditText;
    lateinit var boutonAjouterMemo : Button;
    lateinit var boutonDate :Button
    lateinit var champDate : TextView
    val ecouteur  =  Ecouteur()
    var dateChoisie:LocalDate = LocalDate.now().plusDays(1)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.enableEdgeToEdge()
        setContentView(R.layout.activity_ajouter)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v: View, insets: WindowInsetsCompat ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets

    }


        champMemo = findViewById(R.id.champMemo);
        boutonAjouterMemo = findViewById(R.id.boutonAJouterMemo);
        boutonDate = findViewById(R.id.boutonDate);
        champDate = findViewById(R.id.date);
        boutonAjouterMemo.setOnClickListener(ecouteur);
        boutonDate.setOnClickListener(ecouteur);


}



    inner class Ecouteur : OnClickListener, DatePickerDialog.OnDateSetListener {
        override fun onClick(v: View?) {
           if ( v== boutonAjouterMemo) {
               SingletonListeMemos.getInstance().ajouterMemo(Memo(champMemo.text.toString(), dateChoisie) );
               finish();
           }
            else if (v==boutonDate){
                val d = DatePickerDialog(this@AjouterActivity);
                d.setOnDateSetListener(this);
                d.show();
           }


        }

        override fun onDateSet(view: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {
                dateChoisie = LocalDate.of(year, month+1, dayOfMonth);
                champDate.setText(dateChoisie.toString());
        }

    }


}