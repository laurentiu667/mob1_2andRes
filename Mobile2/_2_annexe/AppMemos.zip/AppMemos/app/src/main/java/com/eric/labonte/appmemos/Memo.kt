package com.eric.labonte.appmemos

import java.io.Serializable
import java.time.LocalDate
// placant les variables public pas besoin de get / set en kotlin
class Memo (  var memoCommeTel:String,   var echeance:LocalDate)
{


}