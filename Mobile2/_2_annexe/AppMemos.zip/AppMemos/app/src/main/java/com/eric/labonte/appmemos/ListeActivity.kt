package com.eric.labonte.appmemos

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.Vector

class ListeActivity : AppCompatActivity() {
    lateinit var liste: ListView;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.enableEdgeToEdge()
        setContentView(R.layout.activity_liste)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v: View, insets: WindowInsetsCompat ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets // vu que c'ets une expression lambda et que c'est le dernier paramaètre, on peut omettre le return
        }

        liste = findViewById(R.id.liste);
        val adapter =
            ArrayAdapter(this, android.R.layout.simple_list_item_1, convertir());
        liste.setAdapter(adapter);
    }

   fun convertir():Vector<String>
   {
       val vector = Vector<String>();
       val listeMemos = SingletonListeMemos.getInstance().liste
       for (memo in listeMemos) {
           vector.add(memo.memoCommeTel);
       }
       return vector;
   }


}