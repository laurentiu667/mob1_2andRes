export const liste = [{
    name: 'Symphonie pastorale',
    artist: 'Ludwig Beethoven',
    url: 'https://i.imgur.com/uCCSYOg.jpeg',
      
  }, {
    name: 'Symphonie du Nouveau Monde',
    artist: 'Antonin Dvorak',
    url: 'https://i.imgur.com/Ua3EOJJ.png',
  
  }, {
    name: 'Marche hongroise',
    artist: 'Hector Berlioz',
    url: 'https://i.imgur.com/30AGuvz.jpeg',
    
  }, {
    name: 'Rhapsodies hongroises',
    artist: 'Franz Liszt',
    url: 'https://i.imgur.com/pgCvWDX.jpeg',

  } ];
  