/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */



import {

  Text,
  Button,
  Image,
  View,
  StyleSheet,
} from 'react-native';

import { liste } from '../donnees/donnees.js'; // les données sous forme de tableau, je les recupere

function Galerie() {
  let index = 0;

  let oeuvre = liste[index];
  const image = { uri: oeuvre.url };

  function clic() {
    index = index + 1;
  }

  return (

    <View style={styles.main}>
      <Button onPress={clic} title="suivant" />
      <Text>
        {oeuvre.name + " de " + oeuvre.artist}
      </Text>
      <Text>
        ({index + 1} of {liste.length})
      </Text>
      <Image style={styles.image} source={image}/>

    </View>
  );
}


const styles = StyleSheet.create(
  {
    image: {
      width: 160,
      height: 160,
    },

    main: {
      alignItems: 'center'
    }
  }
)
export default Galerie;
